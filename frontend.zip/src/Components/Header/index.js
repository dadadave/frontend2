import './Header.css'

const Header = () => {
    return (
      <header>
        <h1>Image Uploader</h1>
      </header>
    );
  }
  export default Header