import './Footer.css'

const Footer = () => {
    return (
      <footer>
        <p>Copyright &copy; 2023 Makiti</p>
      </footer>
    );
  }
  export default Footer